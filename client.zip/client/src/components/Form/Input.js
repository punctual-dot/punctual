import React from "react";

export const Input = props =>
  <div className="form-group" width="30px">
    <input className="form-control" {...props} />
  </div>;

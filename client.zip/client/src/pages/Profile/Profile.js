import React, { Component } from "react";


class Profile extends Component {

  render() {
    return (
		<div>

      		<h1>Profile Profile Profile <small>Subtext for profile if we want to</small></h1>

  		</div>
   )
  }
}
export default Profile;

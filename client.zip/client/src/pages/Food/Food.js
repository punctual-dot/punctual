import React, { Component } from "react";


class Food extends Component {

  render() {
    return (
		<div>

      <h1>Food Food Food <small>Subtext for food if we want to</small></h1>

  
    </div>
    )
  }
}
export default Food;

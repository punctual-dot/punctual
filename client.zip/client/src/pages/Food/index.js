export { default } from "./Food.js";
